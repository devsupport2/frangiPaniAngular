export class Author {
  id: number;
  authorName: string;
  description: string;
  imagePath: string;
  isActive:number;
  image: String;
}
