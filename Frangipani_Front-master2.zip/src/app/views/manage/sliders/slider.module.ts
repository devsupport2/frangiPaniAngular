// Angular
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { SliderComponent } from './slider.component';
import { AddComponent } from './add.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';


// Theme Routing
import { SliderRoutingModule } from './slider-routing.module';

import { ImageCropperModule } from 'ngx-image-cropper';

@NgModule({
  imports: [
    CommonModule,
    SliderRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    ImageCropperModule
  ],
  declarations: [
    SliderComponent,
    AddComponent  
    
  ]
})
export class SliderModule { }
