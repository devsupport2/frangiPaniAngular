import { Slider } from './slider';

describe('Slider', () => {
  it('should create an instance', () => {
    expect(new Slider()).toBeTruthy();
  });
});
