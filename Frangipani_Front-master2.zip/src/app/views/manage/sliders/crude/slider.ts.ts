export class  Slider {
  id: number;
  sliderName: string;
  description: string;
  image: string;
  isActive:number;
  detailLink : string;
  buyNowLink : string;
  title : string;
  subTitle : string;
}

