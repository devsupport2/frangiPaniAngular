export class ProductTab {
    id: number;
    productId: number;
    tabName: number;
    description: number;
    sequence: number; 
    isActive:number;
  
  }