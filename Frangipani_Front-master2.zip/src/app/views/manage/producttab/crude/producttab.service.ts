import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductTabService {

  private baseUrl = 'http://frangipanibookstest.com/api/producttab/producttabs';
  private productUrl = 'http://frangipanibookstest.com/api/product/products';

  constructor(private http: HttpClient) { }

  getProductTab(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/${id}`);
  }

  createProductTab(Product: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`, Product);
  }

  updateProductTab(id: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/${id}`, value);
  }

  updateProductStatus(id: number ,value: any) {    
    this.http.put(this.baseUrl+"/"+id, value).subscribe(data => {
      console.log(data);
    },
    error => {
      console.log('Log the error here: ', error);
      });    
  }

  getProduct(): Observable<any> {
    return this.http.get(`${this.productUrl}`);
  }


  deleteProductTab(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`, { responseType: 'text' });
  }

  getProductTabList(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/list/${id}`);
  }
}