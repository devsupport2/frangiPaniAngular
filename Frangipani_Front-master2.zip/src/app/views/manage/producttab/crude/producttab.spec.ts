import { ProductTab } from './producttab';

describe('ProductTab', () => {
  it('should create an instance', () => {
    expect(new ProductTab()).toBeTruthy();
  });
});