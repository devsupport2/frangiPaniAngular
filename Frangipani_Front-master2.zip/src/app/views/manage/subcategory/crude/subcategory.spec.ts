import { Subcategory } from './subcategory';

describe('Subcategory', () => {
  it('should create an instance', () => {
    expect(new Subcategory()).toBeTruthy();
  });
});
