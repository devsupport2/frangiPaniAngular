export class Subcategory {
    id: number;
    categoryName: string;
    description: string;
    parentId : number;
    isActive : number;
    
}