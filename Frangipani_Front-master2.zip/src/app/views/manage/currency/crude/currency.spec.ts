import { Currency } from './currency';

describe('Currency', () => {
  it('should create an instance', () => {
    expect(new Currency()).toBeTruthy();
  });
});
