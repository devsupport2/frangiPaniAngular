export class Currency {
    id: number;
    currencyName: string;
    currencySymbol: string;
    isActive:number;
  }