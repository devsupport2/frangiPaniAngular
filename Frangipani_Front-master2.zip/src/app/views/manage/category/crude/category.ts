export class Category {
  id: number;
  categoryName: string;
  description: string;
  isActive: number;
  image: String;
}
